// This file was moved to Mirror/CompilerSymbols in Mirror 4.0
// The purpose of this file is to get the old file overwritten
// when users update from the asset store to prevent a flood of errors
// from having the old file still in the project as a straggler.
