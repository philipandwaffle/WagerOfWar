// This file was removed in Mirror 3.4.9
// The purpose of this file is to get the old file overwritten
// when users update from the asset store to prevent a flood of errors
// from having the old file still in the project as a straggler.
// This file will be dropped from the Asset Store package in May 2019
