namespace Mirror.Discovery
{
    public class ServerRequest : MessageBase { }
}
