using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Mirror.Tests")]
